import java.util.Map;

public interface ExpenseCalculation {
	
	
	public Map<String,Double> calculateMonthlyPaperExpense(String Papers);
	public Map<String,Double> calculateWeeklyPaperExpense(String Papers);
	public Map<String,Double> calculateByWeeklyPaperExpense(String Papers);
	

}
