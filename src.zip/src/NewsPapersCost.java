import java.util.HashMap;
import java.util.Map;

public class NewsPapersCost {
	public Map<String,Double> getPapersCost()
	{
		Map<String,Double> papersCost = new HashMap<String,Double>();
		papersCost.put("TOI_weekdays",3.0);
		papersCost.put("TOI_Saturday", 5.0);
		papersCost.put("TOI_Sunday", 6.0);
		papersCost.put("Hindu_weekdays", 2.5);
		papersCost.put("Hindu_Saturday", 4.0);
		papersCost.put("Hindu_Sunday", 4.0);
		papersCost.put("ET_weekdays", 2.0);
		papersCost.put("ET_Saturday", 2.0);
		papersCost.put("ET_Sunday", 10.0);
		papersCost.put("BM_weekdays", 1.5);
		papersCost.put("BM_Saturday",1.5);
		papersCost.put("BM_Sunday",1.5);
		papersCost.put("HT_weekdays",2.0);
		papersCost.put("HT_Saturday",4.0);
		papersCost.put("HT_Sunday",4.0);
		
		return papersCost;
	}


}
