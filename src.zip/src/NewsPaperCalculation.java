import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NewsPaperCalculation implements ExpenseCalculation {

	public static void main(String[] args) {
	
		
		NewsPaperCalculation newspaperCost = new NewsPaperCalculation();
		
		 Map<String,Double> cost = newspaperCost.calculateMonthlyPaperExpense("hindu,TOI,bm");
		
		 System.out.println(cost);
		
		
		
	}

	
	
	
	
	
	@Override
	public Map<String,Double> calculateMonthlyPaperExpense(String papers) {
		// TODO Auto-generated method stub
		int weekdays = 16;
		int saturday = 4;
	    int sundays =  4;
	    Map<String,Double> papersTotalCost = new HashMap<String,Double>();
	    Map<String,Double> papersCost = new NewsPapersCost().getPapersCost();
	    String [] papersList=papers.split(",");
	    
	    for(String paper:papersList)
	    {
	    	double totalcost = 0.0;
	    		switch(paper.toUpperCase())
	    		{
	    			case "TOI":
	    				
	    				totalcost+=(papersCost.get("TOI_weekdays")*weekdays);
	    				totalcost+=(papersCost.get("TOI_Saturday")*saturday);
	    				totalcost+=(papersCost.get("TOI_Sunday")*sundays);
	    				papersTotalCost.put(paper, totalcost);
	    				break;
	    			case "HINDU":
	    				
	    				totalcost+=(papersCost.get("Hindu_weekdays")*weekdays);
	    				totalcost+=(papersCost.get("Hindu_Saturday")*saturday);
	    				totalcost+=(papersCost.get("Hindu_Sunday")*sundays);
	    				papersTotalCost.put(paper, totalcost);
	    				break;
	    			case "ET":
	    				
	    				totalcost+=(papersCost.get("ET_weekdays")*weekdays);
	    				totalcost+=(papersCost.get("ET_Saturday")*saturday);
	    				totalcost+=(papersCost.get("ET_Sunday")*sundays);
	    				papersTotalCost.put(paper, totalcost);
	    				break;
	    			case "BM":
	    				
	    				totalcost+=(papersCost.get("BM_weekdays")*weekdays);
	    				totalcost+=(papersCost.get("BM_Saturday")*saturday);
	    				totalcost+=(papersCost.get("BM_Sunday")*sundays);
	    				papersTotalCost.put(paper, totalcost);
	    				break;
	    			case "HT":
	    				
	    				totalcost+=(papersCost.get("HT_weekdays")*weekdays);
	    				totalcost+=(papersCost.get("HT_weekdays")*saturday);
	    				totalcost+=(papersCost.get("HT_weekdays")*sundays);
	    				papersTotalCost.put(paper, totalcost);
	    				break;
	    			default:
	    				papersTotalCost.put("Invalid Paper Name", totalcost);
	    				
	    			
	    		}
	    		
	    	
	    }
	    
		return papersTotalCost;
	}
	
	

	@Override
	public Map<String, Double> calculateWeeklyPaperExpense(String Papers) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Double> calculateByWeeklyPaperExpense(String Papers) {
		// TODO Auto-generated method stub
		return null;
	}

}
